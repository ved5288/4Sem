#!/bin/sh
#Shell script to run the server
./bin/Server 127.0.0.1 1400 101100
